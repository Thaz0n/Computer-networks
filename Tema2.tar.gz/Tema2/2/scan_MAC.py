from scapy.all import *
import sys

eth = Ether(dst = "ff:ff:ff:ff:ff:ff")
arp = ARP(pdst = '198.13.13.0/16')

if __name__ == "__main__":
    print("Scan start: ")
    answered, unanswered = srp(eth / arp, timeout = 5)
    print ("\nIP ----------- MAC\n")
    for sent, received in answered:
        print received.sprintf(r"%ARP.psrc%" + " -- " + "%Ether.src%") 

