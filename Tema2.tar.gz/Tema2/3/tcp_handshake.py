from scapy.all import *
from struct import *
import os

#adauga regula in firewall 
os.system("iptables -A OUTPUT -p tcp --tcp-flags RST RST -j DROP")
print("Added firewall rule for packet permission.")

ip = IP()
ip.src = '198.13.0.15' #mid1
ip.dst = '198.13.0.14' #rt1
ip.tos = int('011110' + '11', 2) #DSCP si ECN


tcp = TCP()
tcp.sport = 54321
tcp.dport = 10000

option = 'MSS'
op_index = TCPOptions[1][option] 
op_format = TCPOptions[0][op_index]
val = struct.pack(op_format[1], 2) 
tcp.options = [(option, val)]

tcp.seq = 100

tcp.flags = 'S' #SYN
answer_syn_ack = sr1(ip/tcp)

tcp.seq += 1
tcp.ack = answer_syn_ack.seq + 1

tcp.flags = 'A' #ACK
ACK = ip / tcp
send(ACK)

cuvant='cuvant'
for x in range(0, 3):
    tcp.flags = 'PAEC'
    tcp.ack = answer_syn_ack.seq + 1
    ch=cuvant[x]
    rcv = sr1(ip/tcp/ch)
    tcp.seq += 1

tcp.flags='R'
RES = ip/tcp
send(RES)







