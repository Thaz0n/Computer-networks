import socket
import logging
import time

logging.basicConfig(format = u'[LINE:%(lineno)d]# %(levelname)-8s [%(asctime)s]  %(message)s', level = logging.NOTSET)

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

port = 10000
adr = '0.0.0.0'
server_address = (adr, port)

if __name__ == "__main__":
    sock.bind(server_address)
    logging.info("Server has started on %s and port %d", adr, port)
    sock.listen(1)
    logging.info('Waiting for connection...')
    conex, address = sock.accept()
    logging.info("Performing handshake with %s", address)
    while True:
        data = conex.recv(1024)
        logging.info('Received content: "%s"', data)
        data= str(data).upper()
        conex.send(data)
    conex.close()
    sock.close()


