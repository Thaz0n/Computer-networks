import socket
import threading
import random
import time

lock = threading.Lock()

port = 10000
client_address = "198.13.0.14"
client = (client_address, port)

current_package = 0

class Server:
        def __init__(self):
            self.socket_sender = self.sender()
            self.socket_listener = self.lisening()
            print "Server was started ... "
            while True:
                global current_package
                data, source = self.socket_listener.recvfrom(4)
                data = int(data)
                if int(data) == (current_package + 1):
                    current_package = data
                    print "Server received ", current_package
                else:
                    print "Packet was not received."
                t = threading.Thread(target=send, args=[self.socket_sender, current_package])
                t.start()

        def lisening(self):
            socket_listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            listen_addr = ("", port)
            socket_listener.bind(listen_addr)
            return socket_listener


        def sender(self):
            socker_sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            return socker_sender


        def send(self,socket_sender, data):
            global client
            self.socket_sender.sendto(str(data), client)
            print "Send confirmation for: ", data




server = Server()



