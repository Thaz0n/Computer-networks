import socket
import threading
import time
import signal
import sys

port = 10000
address = "198.13.0.1"
server = (address, port)

current_package = 1
windows_size = 5
last_package = 0

class Client:
        def __init__(self): 
            print "Start client ... "
            socker_sender = self.sender()
            socket_listener = self.lisening()
            t1 = threading.Thread(target=self.listen, args=[socket_listener])
            t2 = threading.Thread(target=self.send, args=[socker_sender])
            t1.daemon = True
            t2.daemon = True
            t1.start()
            t2.start()
            old_package = 0
            while last_package < 100:
                time.sleep(5)
                if(last_package == old_package):
                    print "Package not received: ", last_package
                    current_package = last_package
                    old_package = last_package
                    windows_size = 5
                old_package = last_package
                print "Current", last_package, old_package

        def lisening(self):
            socket_listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            socket_listener.bind(("", port))
            return socket_listener


        def sender(self):
            socker_sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            return socker_sender


        def send(self,socker_sender):
            global current_package
            global server
            global windows_size
            while(current_package <= 100):
                time.sleep(1)
                if windows_size > 0:
                    socker_sender.sendto(str(current_package), server)
                    print "Send", current_package
                    current_package = current_package + 1
                    windows_size = windows_size - 1


        def listen(self,socket_listener):
            global windows_size
            global last_package
            global current_package
            while True:
                data, source = socket_listener.recvfrom(4)
                data = int(data)
                if data > last_package:
                    print "Lost package ", last_package, " window size ", windows_size
                    windows_size = windows_size + data - last_package
                    last_package = data

                    #print "Packet primit ", data
                else:
                    current_package = data
                    windows_size = 5
                    print "Lost package ", data

client = Client()

